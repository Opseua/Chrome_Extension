function getDateHour() {
    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0'); // Mês começa do 0
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    return `${day}/${month} ${hours}:${minutes}:${seconds}`;
}

// A API de alarms precisa ser declarada no manifest.json
// dentro da seção "permissions"
// "permissions": ["alarms"]

// 1. Crie a conexão WebSocket globalmente
let url = 'ws://127.0.0.1:8889/?roo=CHROME'
const ws = new WebSocket(url);

// 2. Agende o alarme para ser executado a cada 20 segundos
chrome.alarms.create('pingWebSocket', {
    periodInMinutes: 0.333 // Aproximadamente 20 segundos
});

// 3. Adicione um listener para o alarme
chrome.alarms.onAlarm.addListener((alarm) => {
    // Verifique se o alarme que disparou é o nosso
    if (alarm.name === 'pingWebSocket') {
        if (ws.readyState === WebSocket.OPEN) {
            ws.send('ping');
            // console.log(`${getDateHour()} Ping enviado pelo alarme`)
        } else {
            console.log(`${getDateHour()} Tentando reconectar...`)
            // Lógica de reconexão caso a conexão caia
            ws = new WebSocket(url);
        }
    }
});

// Outros listeners da sua conexão
ws.onopen = () => {
    console.log(`${getDateHour()} Conexão WebSocket aberta`)
};

ws.onmessage = (event) => {
    // console.log(`${getDateHour()} Mensagem recebida do servidor:`, event.data)
};

ws.onclose = () => {
    console.log(`${getDateHour()} Conexão WebSocket fechada`)
};

ws.onerror = (error) => {
    console.log(`${getDateHour()} Erro no WebSocket:`, error)
};


console.log(`${getDateHour()} INICIOU`)
setInterval(() => {
    console.log(`${getDateHour()} FUNCIONANDO`)
}, 5 * 60 * 1000); // x MINUTOS