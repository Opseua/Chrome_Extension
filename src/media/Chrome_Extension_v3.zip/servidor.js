import { WebSocketServer } from 'ws'

// NÃO FAÇA MUITAS QUEBRAS DE LINHAS, ISSO VAI DEIXAR O CÓDIGO MUITO LONGO

let wss = new WebSocketServer({ port: 7777 })
let rooms = new Map() // sala => Set(ws)

function genId() {
    let ts = Date.now()
    let rnd = Math.floor(Math.random() * 1000).toString().padStart(3, '0')
    return `ID_${ts}_${rnd}`
}

function send(ws, obj) {
    try {
        ws.send(JSON.stringify(obj))
    } catch { }
}

wss.on('connection', (ws, req) => {
    let params = new URLSearchParams(req.url.split('?')[1])
    let sala = params.get('sala')
    if (!sala) { ws.close(); return }

    if (!rooms.has(sala)) rooms.set(sala, new Set())
    rooms.get(sala).add(ws)
    console.log(`[WS] Cliente conectado na sala: ${sala}`)

    ws.on('close', () => {
        let set = rooms.get(sala)
        if (set) {
            set.delete(ws)
            if (set.size === 0) rooms.delete(sala)
        }
        console.log(`[WS] Cliente saiu da sala: ${sala}`)
    })

    ws.on('message', raw => {
        let data
        try { data = JSON.parse(raw) } catch { return }

        let { destination, retInf, secondsAwait = 10, message } = data
        let messageId = genId()

        let regex = new RegExp('^' + destination.replace(/\*/g, '.*') + '$')
        let destRooms = [...rooms.entries()].filter(([name]) => regex.test(name))

        if (destRooms.length === 0) {
            send(ws, {
                messageId,
                message: { ret: false, msg: `WS: ERRO | DESTINO INVÁLIDO '${destination}'` }
            })
            return
        }

        let pending = []
        for (let [name, clients] of destRooms) {
            for (let cli of clients) {
                if (cli === ws) continue

                if (retInf) {
                    pending.push(new Promise(resolve => {
                        let timeout = setTimeout(() => resolve(null), secondsAwait * 1000)
                        cli.once('message', ans => {
                            clearTimeout(timeout)
                            resolve(ans.toString())
                        })
                        cli.send(message)
                    }))
                } else {
                    cli.send(message)
                }
            }
        }

        if (!retInf) {
            send(ws, {
                messageId,
                message: { ret: true, msg: `WS: OK '${destination}'` }
            })
        } else {
            Promise.race([
                Promise.all(pending),
                new Promise(r => setTimeout(() => r(null), secondsAwait * 1000))
            ]).then(responses => {
                if (responses && responses.some(r => r !== null)) {
                    send(ws, {
                        messageId,
                        message: { ret: true, msg: 'WS: OK', res: responses.filter(Boolean)[0] }
                    })
                } else {
                    send(ws, {
                        messageId,
                        message: { ret: false, msg: `WS: ERRO | NÃO RESPONDEU A TEMPO '${destination}'` }
                    })
                }
            })
        }
    })
})

console.log('[WS] Servidor rodando em ws://127.0.0.1:7777')
